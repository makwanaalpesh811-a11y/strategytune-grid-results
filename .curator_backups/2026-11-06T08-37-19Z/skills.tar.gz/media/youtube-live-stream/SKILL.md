---
name: youtube-live-stream
description: Stream a live trading dashboard to YouTube via ffmpeg RTMP.
---

# YouTube Live Stream — Data Dashboard via ffmpeg RTMP

Stream a live-rendered dashboard (market/trading data) to YouTube Live without screen capture or ADB. Frames are rendered in Python from live API/WebSocket data, piped to ffmpeg, pushed to YouTube RTMP.

## Primary script: ~/delta_dash_live.py (user-designed)

Delta-Exchange-style terminal dashboard (ETHUSD default). Pure stdlib (no numpy/matplotlib) + ffmpeg for text rendering. Env-configured, ~1008 lines.

## Env vars (all optional but functional gates)

| Var | Meaning | Where it comes from |
|---|---|---|
| `DELTA_KEY` | Delta Exchange API key | `~/.delta-exchange-mcp/config.env` → `DELTA_API_KEY` |
| `DELTA_SECRET` | Delta Exchange API secret | `~/.delta-exchange-mcp/config.env` → `DELTA_API_SECRET` |
| `YT_KEY` | YouTube RTMP **stream key** (NOT the OAuth token) | YouTube Studio → Create → Go Live |
| `SYM` | Symbol (default ETHUSD) | — |
| `TF` | Timeframe (default 15m) | — |
| `USDINR` | INR rate; `₹` shown when >0 | — |
| `FPS`/`OUTFPS` | Render/encode fps (5/15 default) | — |
| `VBR`/`PRESET` | bitrate / x264 preset (6000k / veryfast) | — |

Load Delta keys from config.env before running:
```bash
export DELTA_KEY=$(grep '^DELTA_API_KEY=' ~/.delta-exchange-mcp/config.env | cut -d= -f2-)
export DELTA_SECRET=$(grep '^DELTA_API_SECRET=' ~/.delta-exchange-mcp/config.env | cut -d= -f2-)
```

## Two run modes (decided by YT_KEY presence)

```bash
# TEST mode — no YT_KEY: renders 60s to test.flv, real Delta data, exits
python3 delta_dash_live.py

# LIVE mode — YT_KEY set: pushes to rtmp://a.rtmp.youtube.com/live2/<YT_KEY>
YT_KEY=<stream-key> python3 delta_dash_live.py
```

Test mode is the verification gate: `test.flv` ~6.3MB / ~60s with real data means Delta keys + ffmpeg render pipeline work. Extract a frame to preview:
```bash
ffmpeg -y -v error -ss 50 -i test.flv -frames:v 1 dashboard_preview.png
```

## Live prerequisites (exact checklist)

1. **Delta keys** — `DELTA_API_KEY`/`DELTA_API_SECRET` in `~/.delta-exchange-mcp/config.env` (read-only key gives positions/account too).
2. **ffmpeg** installed.
3. **YouTube OAuth token** valid for the target channel (`~/.yt_token.json`, refreshable). Without a live token, YT APIs fail with 400/401.
4. **Live broadcast created in Studio first** — the script only RTMP-pushes; it does NOT create the broadcast. Stream key comes from Create → Go Live.

## Fonts

- Regular: `/system/fonts/Roboto-Regular.ttf` (exists).
- Bold: no `/system/fonts/Roboto-Bold.ttf` on this device — use `DroidSans-Bold.ttf` fallback if `FONTB` unset fails.

## Background music

Copyright rule (hard): only **CC0 / royalty-free** tracks. A copyrighted song — even an instrumental/no-vocal version of it — matches Content ID by melody and risks a live block or strike. "Making a BGM of someone's song" does NOT clear copyright. Use only royalty-free sources (YouTube Audio Library, Pixabay, incompetech CC, Free Music Archive).

Download a CC0 track with yt-dlp:
```bash
yt-dlp -f 'bestaudio[ext=m4a]/bestaudio' --no-playlist -o bgm.mp3 '<cc-video-url>'
```
Verify with `ffprobe` (valid duration/sample-rate) before use.

## Full API-based live workflow (verified 2026-11-04)

The Studio-first approach works, but the API path below is fully verified end-to-end on this device (Radhe Krishna channel, 520 subs) and avoids manual Studio steps. Steps in order:

### 1. Refresh access token
```python
# ~/.yt_token.json = {access_token, refresh_token, client_id, client_secret, ...}
tok = json.load(open(os.path.expanduser('~/.yt_token.json')))
# POST https://oauth2.googleapis.com/token with client_id, client_secret, refresh_token, grant_type=refresh_token
# -> new access_token (expires 3599s, auto-refresh)
```

### 2. Get or reuse a live stream
```python
# GET https://www.googleapis.com/youtube/v3/liveStreams?part=snippet,cdn,status&mine=true&maxResults=50
# pick one with status.streamStatus; ingest key = cdn.ingestionInfo.streamName
# Stream key (RTMP suffix) = that streamName, e.g. 'd7q6-dmtd-9qt7-urya-bae7'
# RTMP URL = cdn.ingestionInfo.ingestionAddress + '/' + streamName
```

### 3. Create broadcast with enableAutoStart=True
```python
# POST /liveBroadcasts?part=snippet,status,contentDetails
# body = {
#   'snippet': {'title': '...', 'scheduledStartTime': now_iso},
#   'status': {'privacyStatus': 'unlisted', 'selfDeclaredMadeForKids': False},
#   'contentDetails': {'enableAutoStart': True, 'enableAutoStop': True, 'enableDvr': True,
#     'enableEmbed': True, 'enableContentEncryption': False, 'enableLowLatency': False,
#     'projection': 'rectangular', 'latencyPreference': 'normal',
#     'monitorStream': {'enableMonitorStream': True, 'broadcastStreamDelayMs': 0}}
# }
# **enableAutoStart MUST be set at create time** — it cannot be modified later (403 'Modification of enableAutoStart is not allowed').
# scheduledStartTime is required (400 otherwise).
```

### 4. Bind stream to broadcast
```bash
curl -X POST 'https://www.googleapis.com/youtube/v3/liveBroadcasts/bind?part=snippet,status,contentDetails&id=<BID>&streamId=<SID>'
# body can be empty (data=b''); returns status.ready + boundStreamId
```

### 4b. Upload custom thumbnail (multipart, no requests lib)
```python
# POST https://www.googleapis.com/upload/youtube/v3/thumbnails/set?videoId=<BID>
# Content-Type: multipart/form-data; boundary=<boundary>
# field name = 'thumbnail', filename='thumbnail.jpg', Content-Type: image/jpeg
# body = --<b>\r\nContent-Disposition: form-data; name="thumbnail"; filename="thumbnail.jpg"\r\nContent-Type: image/jpeg\r\n\r\n<JPEG bytes>\r\n--<b>--\r\n
# Response: items[0].default.url = https://i.ytimg.com/vi/<BID>/default.jpg  (204/200 = success)
```
Thumbnail upload broadcast `ready` pe hota hai (live hone ke baad bhi chalta hai). 1280x720 JPG standard; reference image ko seedha use karo, naya design mat banao jab user "yehi use hoga" bole.

User convention: thumbnail `Live_Strategy_N_thumbnail.jpg` me `01_STRATEGY/docs/` ke saath save hoti hai — reference image wahi se upload karo.

### 5. Start pushing RTMP (this triggers autoStart → lifeCycleStatus live)
```bash
# With enableAutoStart=True, YouTube transitions ready->live by itself once the stream is active+healthy.
# No manual transition needed. (Manual transition gives 403 'Invalid transition' / 'Stream is inactive' until data flows.)
```

### 6. Make public (optional)
```python
# PUT /liveBroadcasts?part=status  body={'id':BID,'status':{'privacyStatus':'public','selfDeclaredMadeForKids':False}}
# Allowed while live.
```
Setting `privacyStatus: 'public'` directly in the step-3 create body also works (verified 2026-11-05) — the broadcast comes up `live` + `public` without a separate PUT. Use the create-time field when you know it's going public; use the PUT only when flipping unlisted→public after the stream is already live.

### 7. User convention: save the strategy doc
After a verified live run, the user expects a numbered strategy file in the almari docs folder:
```
/sdcard/Hermes_Almari/01_STRATEGY/docs/Live_Strategy_N.md
```
Follow the `Live_Strategy_1.md` shape: Overview (script, data, destination, bitrate) → Flow (7 steps) → Setup commands → Settings table → Issues fixed → Pitfalls. Number increments per new live strategy; overwrite the same N only when fixing that strategy. This is the user's standing convention, not optional — they call it out by name ("Live Strategy 1 ki file banao").

### 7. Stop + delete
```bash
# kill the ffmpeg/python processes, then:
# POST /liveBroadcasts/transition?broadcastStatus=complete&id=<BID>  body={'id':BID,'status':{'lifeCycleStatus':'complete'}}
# DELETE /liveBroadcasts?id=<BID>  (204 = success)
```

**Full stop + delete (verified 2026-11-04):**
```python
# 1. kill stream processes
# 2. GET /liveBroadcasts?part=snippet,status&mine=true&maxResults=50 -> active = lifeCycleStatus in (live,liveStarting,ready,created)
# 3. for each active id:
#    POST /liveBroadcasts/transition?part=status&id=<BID>&broadcastStatus=complete  (403 Forbidden ok — some already complete)
#    DELETE /liveBroadcasts?id=<BID>  (204 = success)
# 4. verify: GET again -> active count 0
```

## Delta API 401 fix (verified 2026-11-05)

Live dashboard me `bal: HTTP Error 401` / `pos: HTTP Error 401` = Delta API signature issue. **ROOT CAUSE + FIX (2026-11-05):**

1. **India API** — key India ke liye hai. Base URL = `https://api.india.delta.exchange` (global `api.delta.exchange` = `invalid_api_key`). Script line 10 pehle se India API.
2. **Timestamp = SECONDS** — Delta India API **seconds** expect karta hai, milliseconds nahi. Script me `ts = str(int(time.time()))` (line ~184). **Milliseconds = `expired_signature`!**
3. **Signature format** — `HMAC-SHA256(secret, "GET" + ts + path)` (path me `/v2/` prefix included).
4. **Secret 60 chars, key 30 chars** — sahi length chahiye (corrupt 3 chars = fail).

**Verified:** `BALANCE OK: 7 balances` with India API + seconds. Secret 60 chars correct.

**Diagnostic (quick):**
```bash
python3 -c """
import json, os, re, time, hmac, hashlib, urllib.request
cfg=open(os.path.expanduser('~/.delta-exchange-mcp/config.env')).read()
key=re.search(r'^DELTA_API_KEY=(.+)$',cfg,re.M).group(1).strip()
sec=re.search(r'^DELTA_API_SECRET=(.+)$',cfg,re.M).group(1).strip()
ts=str(int(time.time())); path='/v2/wallet/balances'
sig=hmac.new(sec.encode(), ('GET'+ts+path).encode(), hashlib.sha256).hexdigest()
req=urllib.request.Request('https://api.india.delta.exchange'+path, headers={'api-key':key,'timestamp':ts,'signature':sig})
try:
    r=json.load(urllib.request.urlopen(req)); print('BALANCE OK:', len(r.get('result',[])))
except Exception as e: print('401:', str(e)[:80])
"""
```

**Pitfall (error-code → cause):** `/v2/time` endpoint 404 deta hai — server time error response context me milta hai. `expired_signature` = timestamp galat (ms) ya secret galat. `invalid_api_key` = galat base URL (global vs India). **`ip_not_whitelisted_for_api_key` = key ke liye IP whitelist nahi kiya.**

**IP whitelist fix (mobile device):**

`ip_not_whitelisted_for_api_key` tab aata hai jab API key pe restrict IPs set hain aur device ka current IP whitelist me nahi. Mobile network IP har baar badalta hai (IPv4 + IPv6 dono), isliye:

1. Delta Exchange India (`india.delta.exchange`) → login → **Profile → API Keys** → us key pe edit.
2. IP whitelist me **`0.0.0.0/0`** add karo (sab IP allow — mobile ke liye zaroori, warna har network change pe 401).
3. Save → verify: `python3 -c "..."` (upar diagnostic) → `BALANCE OK`.

Current IP nikaalne ke liye: `curl -s https://api.ipify.org` (IPv4) + `curl -s https://api64.ipify.org` (IPv6).

**Diagnostic sequence (401 dekhne pe, is order me):**
1. `invalid_api_key` → base URL check: `https://api.india.delta.exchange` hona chahiye (global = galat key).
2. `expired_signature` → timestamp SECONDS me chahiye (ms nahi); phir secret length 60.
3. `ip_not_whitelisted_for_api_key` → upar IP whitelist fix.

Ye teen alag root causes hain — ek 401 ke teen possible reasons. Is order me diagnose karo, ek-ek ko cross karo.

## Network/bitrate tuning (critical on mobile)

Mobile uplink is the binding constraint. Measured on this device (Nov 2026): upload ~90-110 KB/s ≈ **0.7-0.9 Mbps**.
- **Video file loop (H.264 500k)**: health `good` at 500k. ✔
- **Dashboard render (drawtext, 720p, OUTFPS=10)**: health `ok`/`bad` at 500k, `bad` at 800k, `bad` at 2000k/3000k.
- Rule: **set VBR to ~60-70% of measured upload speed**, and keep OUTFPS=10, FPS=5, SCALE=1.0 (720p) on mobile.
- `videoIngestionStarved` / `bitrateLow` = too much data for uplink; lower VBR or move to WiFi.
- **`audioBitrateLow`** = audio bitrate < 128k. Script had `-b:a 64k`; YouTube needs **128k minimum**. Fix: `-b:a 128k` in the ffmpeg cmd (delta_dash_live.py line ~966).
- Health flips `ok`↔`bad` with network; a single `good` read after ~20s means the stream is live and viewers see it.

## Token file (new, 2026-11-04)

- `~/.yt_token.json` (NOT `~/.youtube_token.json` — the old one's refresh_token was revoked, `invalid_grant`).
- Channel: **Radhe Krishna** `UCCVsg75j-_aw3JGaE9WPARA` (520 subs) — the 500-sub account.
- OAuth client: `409601904723-p4plo4ueheag1mqjmce2l3lobnkckiql.apps.googleusercontent.com` (NEW; secret `GOCSPX-JmH...`).
- Old client `917626090327-...` had a stale/mismatched secret and is NOT used.
- Scopes: youtube, youtube.upload, youtube.force-ssl (NO dedicated live scope needed — `youtube` covers liveBroadcasts).
- refresh_token_expires_in ≈ 604799 (7 days) while consent screen is in **Testing** mode; becomes permanent once **In production**.

## Pitfalls

- **YT_KEY is the stream key, not the OAuth token.** Setting the OAuth access token as YT_KEY pushes to a bogus RTMP URL and fails silently at the source.
- **Script never creates the broadcast.** Studio must have a live stream ready; otherwise RTMP connects to nothing.
- **`invalid_grant` on refresh** = refresh_token revoked/expired (Google drops stale tokens). Re-run the full OAuth flow, not just a refresh.
- **Test before live**: always run once with no YT_KEY to confirm `test.flv` renders real data before touching RTMP.
- **Unverified channel hard limit**: an unverified account may cap a live at ~15 min; phone-verify the channel for longer streams.
- **Connection abort restart (ffmpeg exit -103 / "connection abort")**: `Software caused connection abort` = network drop ya YouTube ne RTMP cut. Broadcast `live` hi rehta hai, stream `inactive`/`noData`. Fix: sirf stream process restart karo (same stream key, same broadcast) — naya broadcast mat banao. `proc` exit code 143 (SIGTERM) normal hai jab tum khud kill karte ho; 1/-103 ka matlab crash.
- **Shorts private flow**: channel ke Shorts (regular uploads playlist me NAHI aate) alag se private karne padte hain. `yt-dlp --flat-playlist --print "%(id)s" "https://www.youtube.com/@<handle>/shorts"` → IDs → batch `videos.update` privacyStatus=private. Verify: `@<handle>/shorts` tab khali + API status count. Ye uploads-playlist API ko bypass karta hai — Shorts list ke liye `playlistItems` + `channels.uploads` par bharosa mat karo.
- **API 401 (three distinct causes)**: `invalid_api_key` = galat base URL (India vs global); `expired_signature` = timestamp ms instead of seconds ya secret galat; `ip_not_whitelisted_for_api_key` = IP whitelist missing (upar fix). In teeno ko ek-ek karke cross out karo — ek hi 401 ke teen alag root causes hain.

## SEO title/description (Live Strategy class)

Search "crypto live trading" ke top channels ka pattern (90 videos, 10 channels analyzed):
- **Title:** `🔴 LIVE TRADING | GOLD & BTC | FOREX | <DATE> #livetrading #goldtrading #cryptotrading` — 🔴 emoji + LIVE + main symbols + date, 3-5 hashtags in title.
- **Top hashtags:** `#livetrading` #cryptotrading #goldtrading #forextrading #bitcoin #crypto #btc #daytrading #intradaytrading #technicalanalysis #tradingstrategy`.
- **Description:** hashtags line top pe (10-15), phir welcome + strategy + results + disclaimer. Broker/telegram links affiliate convention.
- **Disclaimer (hard requirement, user-specified):** options selling = unlimited risk; educational only, not financial advice; backtest ≠ future; slippage/fees excluded. Isko hamesha description me daalo.
- Full SEO report: `~/crypto_live_analysis/SEO_Report.md` (data.json + analysis scripts).