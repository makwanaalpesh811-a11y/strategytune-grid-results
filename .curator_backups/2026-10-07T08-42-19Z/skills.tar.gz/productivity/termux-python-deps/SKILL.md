---
name: termux-python-deps
description: Install numpy/pandas/scipy via pkg on Termux, not pip.
version: 1.0.0
author: SenseNova (curator)
license: MIT
platforms: [android]
metadata:
  hermes:
    tags: [termux, android, pkg-install, numpy, pandas, python-deps, aarch64]
    category: productivity
    related_skills: [termux-native-doc-tools]
---

# Termux Python Dependencies (Scientific / Data)

On Termux (aarch64 Android), PyPI publishes no manylinux wheels for this platform — `pip install numpy pandas` silently falls back to building from source, which chains cmake → numpy → pandas with meson/Cython/g++ and takes 20+ minutes on ARM. It looks like a hang but is genuine compilation. The reliable path is Termux's `pkg`, which ships precompiled aarch64 builds.

## When to Use

- Installing numpy, pandas, scipy, or any C/Cython-heavy Python package on Termux.
- `pip install <pkg>` is compiling a build dependency (meson, Cython, cmake) and has been running for more than a couple of minutes.
- A backgrounded pip install appears stuck with `Installing build dependencies: still running...` repeating in the log.

Not this skill for: pure-Python packages (pyyaml, tabulate, click, requests, pydantic) — those install cleanly with pip, and there is no wheel benefit to switching to `pkg`. Also not for PDF/OCR/image native tools (poppler, tesseract, imagemagick) — use `termux-native-doc-tools`.

## Setup (once, idempotent)

If `pkg` errors with `No mirror or mirror group selected` (a fresh Termux box):

```bash
echo "deb https://packages-cf.termux.dev/apt/termux-main stable main" > $PREFIX/etc/apt/sources.list
pkg update -y
```

Then install precompiled scientific packages:

```bash
pkg install -y python-numpy python-pandas
# optional if needed
pkg install -y python-scipy
```

Current termux-main versions (verify with `pkg search python-numpy`): numpy 2.4.4, pandas 3.0.6, both aarch64.

For pure-Python deps, plain pip is fine and fast (no compiler, no wheels needed):

```bash
pip install --break-system-packages pyyaml tabulate
```

Verify with one call:

```bash
python3 -c "import pandas, numpy, yaml, tabulate; print(pandas.__version__, numpy.__version__)"
```

## Pitfalls

- **pandas 3.0 on Termux stores `datetime64` as microseconds, not nanoseconds.** `.astype('int64')` gives values ~1e15 (µs since epoch) instead of ~1e18 (ns). Converting to unix seconds with `// 10**9` yields a timestamp 1000x too small (looks like Jan 1970). Use `.apply(lambda x: int(x.timestamp()))` for a resolution-independent conversion, or check the value magnitude against known ranges (2026 → ~1.76e9 seconds). This bites when aggregating tick CSVs to OHLCV candles and the timestamps silently turn into 1970.
- **Do not background `pip install pandas numpy` on Termux** — the source build takes 20-40 minutes and can look indefinitely stuck. Recognize the sign: `Installing build dependencies: still running...` in the log, followed by a g++ process compiling cmake-4.x. Kill it and switch to `pkg install -y python-numpy python-pandas` instead.
- **`--only-binary=:all:` on pip is a dead end on Termux** — it returns `No matching distribution found` for numpy/pandas/scipy because no aarch64-linux-android wheels exist on PyPI. Do not chase this path.
- **`pkg` and `pip` coexist fine.** Use `pkg` for precompiled C packages, `pip --break-system-packages` for pure-Python. `pkg install python-pandas` actually shells out to pip internally to install pure-Python deps, so mixing them does not conflict.
- **`pkg install python-pandas` needs `python-numpy` installed or as a dependency resolution.** `pkg install -y python-numpy python-pandas` in one command handles ordering; running them separately also works because pkg resolves deps.
- **A previously started pip source-build that you kill may leave orphan g++ processes.** Check `ps -eo pid,args | grep -E 'g\+\+|_in_process|pip_runner'` after killing the parent, and `kill -9` the stragglers if they survive — they hold memory and slow the subsequent pkg install.
- **Write scripts to `$HOME`, not `/tmp`.** `/tmp` on this environment is read-only; write scripts to `/data/data/com.termux/files/home/` and clean up after use.
- **`which` does not exist** on Termux. Use `[ -x /data/data/com.termux/files/usr/bin/<tool> ]` for presence checks.

## Verify

```bash
python3 -c "import pandas, numpy; print('pandas', pandas.__version__, 'numpy', numpy.__version__)"
```

Both should import cleanly in under a second. If import triggers a build warning or takes more than 5 seconds, the source build is still in progress — kill and switch to `pkg`.

## Not This Skill

- PDF/OCR/image native CLI tools (poppler, tesseract, imagemagick) — `termux-native-doc-tools`.
- Docker/conda/mamba Python environments — not applicable on Termux.
- Non-Termux Linux/macOS — plain `pip install pandas numpy` works there.
