---
name: mcp-public-market-setup
description: "Public MCP setup with no keys and no trade mode."
---

# MCP Public-Market Setup (Read-Only)

Always-on rules: no DELTA_API_KEY/DELTA_API_SECRET; never DELTA_MCP_MODE=trade; backup config; only public-market tools; safe install fallback when uv missing. On Android aarch64: prefer `pip install uv` binary-only; if `--only-binary :all:` fails (pip tag mismatch), do not force unsupported binary — stop and confirm.

Procedure: verify Python>=3.12; check uv/uvx; safe uvx or pip install; Hermes mcp_servers entry with empty env; backup config.yaml; verify public-market tests; confirm no keys, no mutations.
